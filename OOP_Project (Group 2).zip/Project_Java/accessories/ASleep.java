package accessories;

public abstract class ASleep 
{
    public abstract void sleep(String message, int sec);
}



