package endingPackage;

public abstract class EndingPage

{
	public abstract void exit();
}