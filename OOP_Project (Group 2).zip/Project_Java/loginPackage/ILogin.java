package loginPackage;

public interface ILogin
{
	public abstract void loginInfo();	
}