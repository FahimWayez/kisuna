package loginPackage;

public abstract class StartingPage implements ILogin

{
	public abstract void loginInfo();
}